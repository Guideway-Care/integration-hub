import { useState, useCallback } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import {
  Play,
  Loader2,
  CheckCircle2,
  XCircle,
  Clock,
  FileAudio,
  User,
  Upload,
  RefreshCw,
  RotateCcw,
  Cloud,
  Database,
  AlertTriangle,
  FolderUp,
} from "lucide-react";

interface StagingSummary {
  pending: number;
  processing: number;
  downloaded: number;
  failed: number;
  total: number;
}

interface StagingRow {
  id: string;
  call_id: string;
  status: string;
  error_message: string | null;
  batch_id: string | null;
  created_at: string;
  processed_at: string | null;
}

interface RecordingRow {
  id: string;
  contact_id: string;
  acd_contact_id: string;
  agent_id: string | null;
  agent_name: string | null;
  start_date: string | null;
  end_date: string | null;
  duration_seconds: number | null;
  media_type: string | null;
  direction: string | null;
  file_name: string | null;
  gcs_uri: string | null;
  file_size_bytes: number | null;
  call_tags: string | null;
  ingestion_timestamp: string;
}

async function fetchJson<T>(url: string, opts?: RequestInit): Promise<T> {
  const res = await fetch(url, opts);
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(err.error || res.statusText);
  }
  return res.json();
}

const REFRESH_INTERVAL = 600000;

function useLastRefreshTime(queryKey: string) {
  const [lastRefresh, setLastRefresh] = useState<Date | null>(null);
  const onSuccess = useCallback(() => setLastRefresh(new Date()), []);
  return { lastRefresh, onSuccess };
}

function LastRefreshBar({ lastRefresh, onRefresh, isLoading }: { lastRefresh: Date | null; onRefresh: () => void; isLoading: boolean }) {
  return (
    <div className="flex items-center justify-end mb-3">
      <Button variant="ghost" size="sm" onClick={onRefresh} disabled={isLoading} className="h-7 text-xs gap-1.5" data-testid="button-refresh-tab">
        <RefreshCw className={`w-3 h-3 ${isLoading ? "animate-spin" : ""}`} />
        {lastRefresh ? lastRefresh.toLocaleTimeString() : "Refresh"}
      </Button>
    </div>
  );
}

export default function ControlPanel() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [callIdsText, setCallIdsText] = useState("");

  const summaryRefresh = useLastRefreshTime("/api/bq/staging-summary");
  const queueRefresh = useLastRefreshTime("/api/bq/staging-queue");
  const recordingsRefresh = useLastRefreshTime("/api/bq/recordings");

  const { data: summary, isLoading: summaryLoading } = useQuery<StagingSummary>({
    queryKey: ["/api/bq/staging-summary"],
    queryFn: async () => {
      const data = await fetchJson<StagingSummary>("/api/bq/staging-summary");
      summaryRefresh.onSuccess();
      return data;
    },
    refetchInterval: REFRESH_INTERVAL,
  });

  const { data: queue, isLoading: queueLoading, isFetching: queueFetching } = useQuery<StagingRow[]>({
    queryKey: ["/api/bq/staging-queue"],
    queryFn: async () => {
      const data = await fetchJson<StagingRow[]>("/api/bq/staging-queue");
      queueRefresh.onSuccess();
      return data;
    },
    refetchInterval: REFRESH_INTERVAL,
  });

  const { data: recordings, isLoading: recordingsLoading, isFetching: recordingsFetching } = useQuery<RecordingRow[]>({
    queryKey: ["/api/bq/recordings"],
    queryFn: async () => {
      const data = await fetchJson<RecordingRow[]>("/api/bq/recordings");
      recordingsRefresh.onSuccess();
      return data;
    },
    refetchInterval: REFRESH_INTERVAL,
  });

  const addMutation = useMutation({
    mutationFn: async () => {
      const callIds = callIdsText.split(/[\n,]+/).map((s) => s.trim()).filter((s) => s.length > 0);
      if (callIds.length === 0) throw new Error("No call IDs provided");
      return fetchJson<{ added: number; batchId: string }>("/api/bq/staging-add", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ callIds }),
      });
    },
    onSuccess: (data) => {
      setCallIdsText("");
      invalidateAll();
      toast({ title: `Added ${data.added} call IDs`, description: `Batch: ${data.batchId}` });
    },
    onError: (err: Error) => toast({ title: "Failed to add", description: err.message, variant: "destructive" }),
  });

  const resetFailedMutation = useMutation({
    mutationFn: () => fetchJson("/api/bq/staging-reset-failed", { method: "POST" }),
    onSuccess: () => { invalidateAll(); toast({ title: "Failed rows reset to pending" }); },
    onError: (err: Error) => toast({ title: "Reset failed", description: err.message, variant: "destructive" }),
  });

  const runJobMutation = useMutation({
    mutationFn: () => fetchJson<{ message: string; executionName: string }>("/api/bq/run-job", { method: "POST" }),
    onSuccess: (data) => toast({ title: "Processor job started", description: data.executionName }),
    onError: (err: Error) => toast({ title: "Failed to trigger job", description: err.message, variant: "destructive" }),
  });

  const runLoaderMutation = useMutation({
    mutationFn: () => fetchJson<{ message: string; executionName: string }>("/api/bq/run-loader", { method: "POST" }),
    onSuccess: (data) => {
      invalidateAll();
      queryClient.invalidateQueries({ queryKey: ["/api/bq/call-list-status"] });
      toast({ title: "Loader job started", description: data.executionName });
    },
    onError: (err: Error) => toast({ title: "Failed to trigger loader", description: err.message, variant: "destructive" }),
  });

  const { data: callListStatus } = useQuery<{ exists: boolean; lineCount: number }>({
    queryKey: ["/api/bq/call-list-status"],
    queryFn: () => fetchJson("/api/bq/call-list-status"),
    refetchInterval: REFRESH_INTERVAL,
  });

  function invalidateAll() {
    queryClient.invalidateQueries({ queryKey: ["/api/bq/staging-summary"] });
    queryClient.invalidateQueries({ queryKey: ["/api/bq/staging-queue"] });
    queryClient.invalidateQueries({ queryKey: ["/api/bq/recordings"] });
  }

  const s = summary ?? { pending: 0, processing: 0, downloaded: 0, failed: 0, total: 0 };
  const progress = s.total > 0 ? Math.round(((s.downloaded + s.failed) / s.total) * 100) : 0;

  const statusBadge = (status: string) => {
    switch (status) {
      case "downloaded":
        return <Badge className="bg-green-100 text-green-700 border-green-200"><CheckCircle2 className="w-3 h-3 mr-1" />Downloaded</Badge>;
      case "failed":
        return <Badge className="bg-red-100 text-red-700 border-red-200"><XCircle className="w-3 h-3 mr-1" />Failed</Badge>;
      case "processing":
        return <Badge className="bg-blue-100 text-blue-700 border-blue-200"><Loader2 className="w-3 h-3 mr-1 animate-spin" />Processing</Badge>;
      default:
        return <Badge variant="outline"><Clock className="w-3 h-3 mr-1" />Pending</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <Card className="border-border shadow-md overflow-hidden">
        <CardHeader className="bg-gradient-to-r from-card to-accent/20 border-b border-border pb-6">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-2xl font-bold flex items-center gap-3">
                <Cloud className="w-6 h-6 text-primary" />
                Control Panel
              </CardTitle>
              <p className="text-muted-foreground mt-1">
                Live view of <code className="text-xs bg-muted px-1 py-0.5 rounded">incontact.staging_call_queue</code> and <code className="text-xs bg-muted px-1 py-0.5 rounded">incontact.call_recordings</code> in GCP project <code className="text-xs bg-muted px-1 py-0.5 rounded">guidewaycare-476802</code>
              </p>
            </div>
            <Button variant="ghost" size="icon" onClick={() => invalidateAll()} data-testid="button-refresh-all">
              <RefreshCw className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>

        <CardContent className="p-6 space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            <div className="rounded-lg border border-border p-3 bg-muted/30">
              <div className="text-xs text-muted-foreground font-mono mb-1">TOTAL</div>
              <div className="text-2xl font-bold font-mono" data-testid="text-queue-total">
                {summaryLoading ? <Skeleton className="h-8 w-12" /> : s.total}
              </div>
            </div>
            <div className="rounded-lg border border-border p-3 bg-muted/30">
              <div className="text-xs text-muted-foreground font-mono mb-1">PENDING</div>
              <div className="text-2xl font-bold font-mono text-amber-600" data-testid="text-queue-pending">
                {summaryLoading ? <Skeleton className="h-8 w-12" /> : s.pending}
              </div>
            </div>
            <div className="rounded-lg border border-border p-3 bg-muted/30">
              <div className="text-xs text-muted-foreground font-mono mb-1">PROCESSING</div>
              <div className="text-2xl font-bold font-mono text-blue-600" data-testid="text-queue-processing">
                {summaryLoading ? <Skeleton className="h-8 w-12" /> : s.processing}
              </div>
            </div>
            <div className="rounded-lg border border-border p-3 bg-muted/30">
              <div className="text-xs text-muted-foreground font-mono mb-1">DOWNLOADED</div>
              <div className="text-2xl font-bold font-mono text-green-600" data-testid="text-queue-downloaded">
                {summaryLoading ? <Skeleton className="h-8 w-12" /> : s.downloaded}
              </div>
            </div>
            <div className="rounded-lg border border-border p-3 bg-muted/30">
              <div className="text-xs text-muted-foreground font-mono mb-1">FAILED</div>
              <div className="text-2xl font-bold font-mono text-red-600" data-testid="text-queue-failed">
                {summaryLoading ? <Skeleton className="h-8 w-12" /> : s.failed}
              </div>
            </div>
          </div>

          {s.total > 0 && (
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-mono">
                <span>Progress</span>
                <span>{progress}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="rounded-lg border border-border p-4 bg-muted/20 flex flex-col">
              <div className="flex items-center gap-2 mb-3">
                <FolderUp className="w-4 h-4 text-primary" />
                <label className="text-xs font-semibold font-mono">STEP 1: LOAD CALL IDS</label>
              </div>
              <p className="text-xs text-muted-foreground flex-1">
                Reads <code className="bg-muted px-1 py-0.5 rounded text-[10px]">gs://incontact-audio/call_list/call_list.txt</code> and inserts into staging
              </p>
              <Button
                onClick={() => runLoaderMutation.mutate()}
                disabled={runLoaderMutation.isPending}
                className="w-full mt-3"
                size="lg"
                data-testid="button-run-loader"
              >
                {runLoaderMutation.isPending ? (
                  <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Loading...</>
                ) : (
                  <><FolderUp className="w-4 h-4 mr-2" /> Load Call IDs</>
                )}
              </Button>
            </div>

            <div className="rounded-lg border border-border p-4 bg-muted/20 flex flex-col">
              <div className="flex items-center gap-2 mb-3">
                <Play className="w-4 h-4 text-primary" />
                <label className="text-xs font-semibold font-mono">STEP 2: PROCESS CALLS</label>
              </div>
              <p className="text-xs text-muted-foreground">
                Downloads recordings from InContact API, uploads to GCS, writes metadata to BigQuery
              </p>
              <div className="text-xs flex-1 mt-2">
                {s.pending > 0 ? (
                  <span className="text-amber-600 font-medium">{s.pending} calls pending</span>
                ) : (
                  <span className="text-muted-foreground">No pending calls</span>
                )}
              </div>
              <Button
                onClick={() => runJobMutation.mutate()}
                disabled={runJobMutation.isPending || s.pending === 0}
                className="w-full mt-3"
                size="lg"
                data-testid="button-run-job"
              >
                {runJobMutation.isPending ? (
                  <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Triggering...</>
                ) : (
                  <><Play className="w-4 h-4 mr-2" /> Process Calls</>
                )}
              </Button>
            </div>

            <div className="rounded-lg border border-border p-4 bg-muted/20 flex flex-col">
              <div className="flex items-center gap-2 mb-3">
                <Upload className="w-4 h-4 text-muted-foreground" />
                <label className="text-xs font-semibold font-mono">MANUAL ADD</label>
              </div>
              <Textarea
                value={callIdsText}
                onChange={(e) => setCallIdsText(e.target.value)}
                className="font-mono text-xs min-h-[60px] flex-1"
                placeholder={"Call IDs (one per line)"}
                data-testid="textarea-call-ids"
              />
              <Button
                onClick={() => addMutation.mutate()}
                disabled={addMutation.isPending || !callIdsText.trim()}
                className="w-full mt-3"
                variant="secondary"
                data-testid="button-add-to-queue"
              >
                {addMutation.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Upload className="w-4 h-4 mr-2" />}
                Add to Staging
              </Button>
            </div>
          </div>

          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={() => resetFailedMutation.mutate()}
              disabled={resetFailedMutation.isPending || s.failed === 0}
              className="flex-1"
              size="sm"
              data-testid="button-reset-failed"
            >
              {resetFailedMutation.isPending ? <Loader2 className="w-3 h-3 mr-1.5 animate-spin" /> : <RotateCcw className="w-3 h-3 mr-1.5" />}
              Reset Failed → Pending
            </Button>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="queue" className="space-y-4">
        <TabsList>
          <TabsTrigger value="queue" className="gap-2" data-testid="tab-queue">
            <Database className="w-4 h-4" /> Staging Queue {s.total > 0 && <Badge variant="secondary" className="ml-1">{s.total}</Badge>}
          </TabsTrigger>
          <TabsTrigger value="recordings" className="gap-2" data-testid="tab-recordings">
            <FileAudio className="w-4 h-4" /> Call Recordings {recordings?.length ? <Badge variant="secondary" className="ml-1">{recordings.length}</Badge> : null}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="queue">
          <LastRefreshBar
            lastRefresh={queueRefresh.lastRefresh}
            onRefresh={() => queryClient.invalidateQueries({ queryKey: ["/api/bq/staging-queue"] })}
            isLoading={queueFetching}
          />
          {queueLoading ? (
            <Skeleton className="h-[300px] w-full" />
          ) : !queue?.length ? (
            <Card className="border-border shadow-md">
              <CardContent className="p-12 text-center text-muted-foreground">
                <Database className="w-8 h-8 mx-auto mb-3 opacity-40" />
                <p>Staging queue is empty. Add call IDs above to get started.</p>
              </CardContent>
            </Card>
          ) : (
            <Card className="border-border shadow-md overflow-hidden">
              <div className="max-h-[500px] overflow-auto">
                <Table>
                  <TableHeader className="bg-muted/50 sticky top-0">
                    <TableRow>
                      <TableHead className="font-mono text-xs h-10">CALL ID</TableHead>
                      <TableHead className="font-mono text-xs h-10">STATUS</TableHead>
                      <TableHead className="font-mono text-xs h-10">ERROR</TableHead>
                      <TableHead className="font-mono text-xs h-10">BATCH</TableHead>
                      <TableHead className="font-mono text-xs h-10 text-right">CREATED</TableHead>
                      <TableHead className="font-mono text-xs h-10 text-right">PROCESSED</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {queue.map((item) => (
                      <TableRow key={item.id} data-testid={`row-queue-${item.call_id}`}>
                        <TableCell className="font-mono text-sm">{item.call_id}</TableCell>
                        <TableCell>{statusBadge(item.status)}</TableCell>
                        <TableCell className="text-xs text-red-600 max-w-[250px] truncate">
                          {item.error_message ? (
                            <span className="flex items-center gap-1"><AlertTriangle className="w-3 h-3 flex-shrink-0" />{item.error_message}</span>
                          ) : "—"}
                        </TableCell>
                        <TableCell className="font-mono text-[10px] text-muted-foreground">{item.batch_id || "—"}</TableCell>
                        <TableCell className="text-right text-xs font-mono text-muted-foreground">
                          {item.created_at ? new Date(item.created_at).toLocaleString() : "—"}
                        </TableCell>
                        <TableCell className="text-right text-xs font-mono text-muted-foreground">
                          {item.processed_at ? new Date(item.processed_at).toLocaleString() : "—"}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="recordings">
          <LastRefreshBar
            lastRefresh={recordingsRefresh.lastRefresh}
            onRefresh={() => queryClient.invalidateQueries({ queryKey: ["/api/bq/recordings"] })}
            isLoading={recordingsFetching}
          />
          {recordingsLoading ? (
            <Skeleton className="h-[300px] w-full" />
          ) : !recordings?.length ? (
            <Card className="border-border shadow-md">
              <CardContent className="p-12 text-center text-muted-foreground">
                <FileAudio className="w-8 h-8 mx-auto mb-3 opacity-40" />
                <p>No recordings yet. Process the staging queue to download recordings.</p>
              </CardContent>
            </Card>
          ) : (
            <Card className="border-border shadow-md overflow-hidden">
              <div className="overflow-auto">
                <Table>
                  <TableHeader className="bg-muted/50">
                    <TableRow>
                      <TableHead className="font-mono text-xs h-10">CONTACT ID</TableHead>
                      <TableHead className="font-mono text-xs h-10">AGENT</TableHead>
                      <TableHead className="font-mono text-xs h-10">START</TableHead>
                      <TableHead className="font-mono text-xs h-10">DURATION</TableHead>
                      <TableHead className="font-mono text-xs h-10">TYPE</TableHead>
                      <TableHead className="font-mono text-xs h-10">DIRECTION</TableHead>
                      <TableHead className="font-mono text-xs h-10">GCS URI</TableHead>
                      <TableHead className="font-mono text-xs h-10">SIZE</TableHead>
                      <TableHead className="font-mono text-xs h-10">TAGS</TableHead>
                      <TableHead className="font-mono text-xs h-10 text-right">INGESTED</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {recordings.map((rec) => (
                      <TableRow key={rec.id} data-testid={`row-recording-${rec.contact_id}`}>
                        <TableCell className="font-mono text-sm">{rec.contact_id}</TableCell>
                        <TableCell className="text-sm">
                          {rec.agent_name ? (
                            <span className="flex items-center gap-1"><User className="w-3 h-3" />{rec.agent_name}</span>
                          ) : "—"}
                        </TableCell>
                        <TableCell className="font-mono text-xs text-muted-foreground">
                          {rec.start_date ? new Date(rec.start_date).toLocaleString() : "—"}
                        </TableCell>
                        <TableCell className="font-mono text-sm">
                          {rec.duration_seconds != null ? `${Math.floor(rec.duration_seconds / 60)}m ${rec.duration_seconds % 60}s` : "—"}
                        </TableCell>
                        <TableCell className="text-xs">{rec.media_type || "—"}</TableCell>
                        <TableCell className="text-xs">
                          {rec.direction === "IN_BOUND" ? (
                            <Badge variant="outline" className="text-[10px]">Inbound</Badge>
                          ) : rec.direction === "OUT_BOUND" ? (
                            <Badge variant="outline" className="text-[10px]">Outbound</Badge>
                          ) : rec.direction || "—"}
                        </TableCell>
                        <TableCell className="font-mono text-[10px] max-w-[200px] truncate text-muted-foreground">
                          {rec.gcs_uri || "—"}
                        </TableCell>
                        <TableCell className="font-mono text-xs">
                          {rec.file_size_bytes ? `${(rec.file_size_bytes / 1024 / 1024).toFixed(1)} MB` : "—"}
                        </TableCell>
                        <TableCell className="max-w-[150px]">
                          {rec.call_tags ? (() => {
                            try {
                              const tags = JSON.parse(rec.call_tags);
                              return (
                                <div className="flex flex-wrap gap-1">
                                  {tags.map((tag: string, i: number) => (
                                    <Badge key={i} variant="secondary" className="text-[9px]">{tag}</Badge>
                                  ))}
                                </div>
                              );
                            } catch { return <span className="text-xs">{rec.call_tags}</span>; }
                          })() : "—"}
                        </TableCell>
                        <TableCell className="text-right text-xs font-mono text-muted-foreground">
                          {rec.ingestion_timestamp ? new Date(rec.ingestion_timestamp).toLocaleString() : "—"}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
