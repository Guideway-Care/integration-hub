import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import {
  PhoneCall,
  Send,
  Loader2,
  Clock,
  FileAudio,
  User,
  Hash,
  Play,
  ArrowDownRight,
  ArrowUpRight,
  Tag,
  SmilePlus,
} from "lucide-react";

interface ApiResult {
  statusCode: number;
  statusText: string;
  endpoint: string;
  timestamp: string;
  data: any;
}

function formatDuration(startTime: string, endTime: string) {
  const ms = new Date(endTime).getTime() - new Date(startTime).getTime();
  const totalSecs = Math.floor(ms / 1000);
  const mins = Math.floor(totalSecs / 60);
  const secs = totalSecs % 60;
  return `${mins}m ${secs}s`;
}

function formatTime(iso: string) {
  return new Date(iso).toLocaleString();
}

export default function CallTest() {
  const { toast } = useToast();
  const [callId, setCallId] = useState("");
  const [result, setResult] = useState<ApiResult | null>(null);
  const [showRaw, setShowRaw] = useState(false);

  const fetchMutation = useMutation({
    mutationFn: async () => {
      if (!callId.trim()) throw new Error("Please enter a Call ID");
      const res = await fetch("/api/incontact/fetch", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          endpoint: "/media-playback/v1/contacts",
          params: { "acd-call-id": callId.trim() },
        }),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error);
      }
      return res.json() as Promise<ApiResult>;
    },
    onSuccess: (data) => {
      setResult(data);
      toast({ title: `Response: ${data.statusCode} ${data.statusText}` });
    },
    onError: (err: Error) => {
      toast({ title: "Request failed", description: err.message, variant: "destructive" });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchMutation.mutate();
  };

  const recording = result?.data;
  const interaction = recording?.interactions?.[0];
  const interactionData = interaction?.data;
  const participants = interactionData?.participantDataList || [];
  const segments = interactionData?.segmentsDataList || [];
  const categories = interactionData?.categoryMatchesList || [];
  const sentiments = interactionData?.sentiments || [];
  const callTags = interaction?.callTaggingList || [];
  const agent = participants.find((p: any) => p.participantType === "AGENT");
  const hasData = result?.statusCode === 200 && interaction;

  return (
    <div className="space-y-6">
      <Card className="border-border shadow-md overflow-hidden">
        <CardHeader className="bg-gradient-to-r from-card to-accent/20 border-b border-border pb-6">
          <CardTitle className="text-2xl font-bold flex items-center gap-3">
            <PhoneCall className="w-6 h-6 text-primary" />
            Call Recording Lookup
          </CardTitle>
          <p className="text-muted-foreground mt-1">
            Enter an ACD Call ID to retrieve recording data from the InContact MediaPlayback API.
          </p>
        </CardHeader>

        <CardContent className="p-6">
          <form onSubmit={handleSubmit} className="flex gap-3">
            <div className="flex-1">
              <label className="text-xs text-muted-foreground font-mono mb-1 block">ACD CALL ID</label>
              <Input
                value={callId}
                onChange={(e) => setCallId(e.target.value)}
                className="font-mono text-sm"
                placeholder="Enter call ID (e.g. 12345678)"
                data-testid="input-call-id"
              />
            </div>
            <div className="flex items-end">
              <Button
                type="submit"
                disabled={fetchMutation.isPending || !callId.trim()}
                data-testid="button-lookup-call"
              >
                {fetchMutation.isPending ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Send className="w-4 h-4 mr-2" />
                )}
                Lookup
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {result && !hasData && (
        <Card className="border-border shadow-md overflow-hidden">
          <CardHeader className="border-b border-border py-4">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg font-semibold">Response</CardTitle>
              <Badge
                variant="outline"
                className="bg-red-100 text-red-700 border-red-200"
                data-testid="badge-call-status"
              >
                {result.statusCode} {result.statusText}
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="p-5">
            <pre className="text-sm font-mono overflow-auto max-h-[300px] bg-muted/30 rounded-lg p-4 whitespace-pre-wrap break-words" data-testid="text-error-response">
              {typeof result.data === "string" ? result.data : JSON.stringify(result.data, null, 2)}
            </pre>
          </CardContent>
        </Card>
      )}

      {hasData && (
        <>
          <Card className="border-border shadow-md overflow-hidden">
            <CardHeader className="border-b border-border py-4">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg font-semibold flex items-center gap-2">
                  <Hash className="w-4 h-4" />
                  Contact: {recording.acdcontactId}
                </CardTitle>
                <div className="flex items-center gap-3">
                  <Badge variant="outline" className="bg-green-100 text-green-700 border-green-200" data-testid="badge-call-status">
                    {result.statusCode} OK
                  </Badge>
                  <Badge variant="outline" className="font-mono text-xs" data-testid="badge-media-type">
                    <FileAudio className="w-3 h-3 mr-1" />
                    {interaction.mediaType}
                  </Badge>
                </div>
              </div>
            </CardHeader>

            <CardContent className="p-6 space-y-6">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {agent && (
                  <div className="rounded-lg border border-border p-3 bg-muted/30">
                    <div className="text-xs text-muted-foreground font-mono mb-1 flex items-center gap-1">
                      <User className="w-3 h-3" /> AGENT
                    </div>
                    <span className="text-sm font-medium" data-testid="text-agent-name">{agent.agentName}</span>
                  </div>
                )}
                {interactionData?.startTime && interactionData?.endTime && (
                  <div className="rounded-lg border border-border p-3 bg-muted/30">
                    <div className="text-xs text-muted-foreground font-mono mb-1 flex items-center gap-1">
                      <Clock className="w-3 h-3" /> DURATION
                    </div>
                    <span className="text-sm font-mono" data-testid="text-duration">
                      {formatDuration(interactionData.startTime, interactionData.endTime)}
                    </span>
                  </div>
                )}
                {interactionData?.startTime && (
                  <div className="rounded-lg border border-border p-3 bg-muted/30">
                    <div className="text-xs text-muted-foreground font-mono mb-1 flex items-center gap-1">
                      <Clock className="w-3 h-3" /> START TIME
                    </div>
                    <span className="text-xs font-mono" data-testid="text-start-time">
                      {formatTime(interactionData.startTime)}
                    </span>
                  </div>
                )}
                {segments[0] && (
                  <div className="rounded-lg border border-border p-3 bg-muted/30">
                    <div className="text-xs text-muted-foreground font-mono mb-1 flex items-center gap-1">
                      {segments[0].directionType === "IN_BOUND" ? (
                        <ArrowDownRight className="w-3 h-3" />
                      ) : (
                        <ArrowUpRight className="w-3 h-3" />
                      )}
                      DIRECTION
                    </div>
                    <span className="text-sm font-mono" data-testid="text-direction">
                      {segments[0].directionType === "IN_BOUND" ? "Inbound" : "Outbound"}
                    </span>
                  </div>
                )}
              </div>

              {interactionData?.fileToPlayUrl && (
                <div className="rounded-lg border border-primary/30 bg-primary/5 p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="text-sm font-semibold flex items-center gap-2">
                      <Play className="w-4 h-4 text-primary" /> Call Recording
                    </h4>
                    <a
                      href={interactionData.fileToPlayUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs text-primary underline font-mono"
                      data-testid="link-download-recording"
                    >
                      Open in new tab
                    </a>
                  </div>
                  <video
                    controls
                    className="w-full rounded-lg bg-black"
                    src={interactionData.fileToPlayUrl}
                    data-testid="video-recording"
                  >
                    Your browser does not support video playback.
                  </video>
                </div>
              )}

              {callTags.length > 0 && (
                <div className="rounded-lg border border-border p-4 space-y-2">
                  <h4 className="text-sm font-semibold flex items-center gap-2">
                    <Tag className="w-4 h-4" /> Call Tags
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {callTags.map((tag: any, i: number) => (
                      <Badge key={i} variant="secondary" className="font-mono text-xs" data-testid={`badge-tag-${i}`}>
                        {tag.value}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {sentiments.length > 0 && (
                <div className="rounded-lg border border-border p-4 space-y-2">
                  <h4 className="text-sm font-semibold flex items-center gap-2">
                    <SmilePlus className="w-4 h-4" /> Sentiment Analysis
                  </h4>
                  <div className="grid grid-cols-2 gap-3">
                    {sentiments.map((s: any, i: number) => (
                      <div key={i} className="flex items-center gap-2">
                        <Badge
                          variant="outline"
                          className={
                            s.overallSentiment === "POSITIVE"
                              ? "bg-green-100 text-green-700 border-green-200"
                              : s.overallSentiment === "NEGATIVE"
                                ? "bg-red-100 text-red-700 border-red-200"
                                : "bg-amber-100 text-amber-700 border-amber-200"
                          }
                          data-testid={`badge-sentiment-${i}`}
                        >
                          {s.overallSentiment}
                        </Badge>
                        <span className="text-xs text-muted-foreground font-mono">
                          Channel {s.channel} ({s.channel === 0 ? "Agent" : "Customer"})
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {categories.length > 0 && (
                <div className="rounded-lg border border-border p-4 space-y-2">
                  <h4 className="text-sm font-semibold flex items-center gap-2">
                    <Tag className="w-4 h-4" /> Detected Categories
                  </h4>
                  <div className="space-y-2">
                    {categories.map((cat: any, i: number) => (
                      <div key={i} className="flex items-center justify-between text-sm">
                        <span className="font-mono text-xs text-muted-foreground" data-testid={`text-category-${i}`}>
                          {cat.categoryHierarchy.join(" → ")}
                        </span>
                        <Badge variant="outline" className="text-[10px] font-mono">
                          {cat.confidence}% confidence
                        </Badge>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {participants.length > 0 && (
                <div className="rounded-lg border border-border p-4 space-y-2">
                  <h4 className="text-sm font-semibold flex items-center gap-2">
                    <User className="w-4 h-4" /> Participants
                  </h4>
                  <div className="space-y-2">
                    {participants.map((p: any, i: number) => (
                      <div key={i} className="flex items-center gap-3 text-sm">
                        <Badge variant={p.participantType === "AGENT" ? "default" : "secondary"} className="text-xs" data-testid={`badge-participant-${i}`}>
                          {p.participantType}
                        </Badge>
                        <span className="font-mono text-sm">
                          {p.agentName || p.participantId}
                        </span>
                        <span className="text-xs text-muted-foreground font-mono ml-auto">
                          Channel {p.channel}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="border-border shadow-md overflow-hidden">
            <CardHeader className="border-b border-border py-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-semibold">Raw API Response</CardTitle>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowRaw(!showRaw)}
                  data-testid="button-toggle-raw"
                >
                  {showRaw ? "Hide" : "Show"}
                </Button>
              </div>
            </CardHeader>
            {showRaw && (
              <CardContent className="p-0">
                <pre
                  className="p-5 text-xs font-mono overflow-auto max-h-[500px] bg-muted/30 whitespace-pre-wrap break-words"
                  data-testid="text-raw-response"
                >
                  {JSON.stringify(result.data, null, 2)}
                </pre>
              </CardContent>
            )}
          </Card>
        </>
      )}
    </div>
  );
}
