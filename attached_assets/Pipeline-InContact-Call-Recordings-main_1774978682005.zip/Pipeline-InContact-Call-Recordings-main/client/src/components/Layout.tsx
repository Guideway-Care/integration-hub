import { Link, useLocation } from "wouter";
import { Monitor, PhoneCall } from "lucide-react";

const NAV_ITEMS = [
  { href: "/", label: "Control Panel", icon: Monitor },
  { href: "/call-test", label: "Call Lookup", icon: PhoneCall },
];

export default function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  return (
    <div className="min-h-screen bg-background text-foreground font-sans flex">
      <aside className="w-64 border-r border-border bg-card flex flex-col shrink-0 sticky top-0 h-screen">
        <div className="p-5 border-b border-border">
          <h1 className="text-lg font-bold tracking-tight text-primary leading-tight">InContact to GCP Ingestion</h1>
          <p className="text-muted-foreground mt-1 font-mono text-xs">
            Project: <span className="text-foreground font-semibold">guidewaycare-476802</span>
          </p>
        </div>

        <nav className="flex-1 p-3 space-y-1">
          {NAV_ITEMS.map(({ href, label, icon: Icon }) => {
            const isActive = location === href;
            return (
              <Link
                key={href}
                href={href}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                  isActive
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                }`}
                data-testid={`nav-${label.toLowerCase().replace(/\s+/g, "-")}`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                {label}
              </Link>
            );
          })}
        </nav>
      </aside>

      <main className="flex-1 p-8 overflow-auto">
        <div className="max-w-6xl mx-auto">
          {children}
        </div>
      </main>
    </div>
  );
}
