#!/bin/bash
set -euo pipefail

PROJECT="guidewaycare-476802"
REGION="us-central1"
JOB_NAME="incontact-call-processor"
IMAGE="gcr.io/${PROJECT}/${JOB_NAME}"
SERVICE_ACCOUNT="gwc-incontact-cloud-run@${PROJECT}.iam.gserviceaccount.com"

echo "=== Building and deploying Cloud Run job ==="
echo ""

echo "▶ Building container image..."
gcloud builds submit \
  --project="${PROJECT}" \
  --tag="${IMAGE}" \
  cloud-run/

echo ""
echo "▶ Creating/updating Cloud Run job..."
gcloud run jobs replace cloud-run/job.yaml \
  --project="${PROJECT}" \
  --region="${REGION}"

echo ""
echo "=== Deployed successfully ==="
echo ""
echo "To run manually:"
echo "  gcloud run jobs execute ${JOB_NAME} --project=${PROJECT} --region=${REGION}"
echo ""
echo "To view logs:"
echo "  gcloud run jobs logs ${JOB_NAME} --project=${PROJECT} --region=${REGION}"
