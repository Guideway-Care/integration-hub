# Cloud Run Job — InContact Call Processor

Standalone Cloud Run job that processes the BigQuery staging table and downloads call recordings.

## What It Does

1. Authenticates with InContact via GCP Secret Manager credentials
2. Queries `staging_call_queue` for the next pending call
3. Fetches call metadata from the InContact MediaPlayback API
4. Downloads the MP4 recording and uploads to `gs://incontact-audio/`
5. Writes metadata to the `call_recordings` table in BigQuery
6. Marks the staging row as `downloaded`
7. Repeats until no pending rows remain

## Prerequisites

The service account `gwc-incontact-replit-key-mgr@guidewaycare-476802.iam.gserviceaccount.com` needs:

| Role | Purpose |
|------|---------|
| `roles/secretmanager.secretAccessor` | Read InContact API credentials |
| `roles/bigquery.dataEditor` | Read/write staging + recordings tables |
| `roles/bigquery.jobUser` | Run BigQuery queries |
| `roles/storage.objectCreator` | Upload MP4 files to GCS bucket |

## Deploy

```bash
# From repo root
bash cloud-run/deploy.sh
```

This builds the container image, pushes it to GCR, and creates/updates the Cloud Run job.

## Run Manually

```bash
gcloud run jobs execute incontact-call-processor \
  --project=guidewaycare-476802 \
  --region=us-central1
```

## Schedule (Daily Delta)

To run daily via Cloud Scheduler:

```bash
gcloud scheduler jobs create http incontact-daily-processor \
  --project=guidewaycare-476802 \
  --location=us-central1 \
  --schedule="0 6 * * *" \
  --uri="https://us-central1-run.googleapis.com/apis/run.googleapis.com/v1/namespaces/guidewaycare-476802/jobs/incontact-call-processor:run" \
  --http-method=POST \
  --oauth-service-account-email=gwc-incontact-replit-key-mgr@guidewaycare-476802.iam.gserviceaccount.com
```

## Status Flow

```
pending → processing → downloaded
                    ↘ failed
```

## Exit Codes

- `0` — All calls processed successfully
- `1` — One or more calls failed (or fatal error)

Last deployed: 2026-03-11T20:49:28.411Z
