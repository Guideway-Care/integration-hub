#!/bin/bash
set -euo pipefail

PROJECT="guidewaycare-476802"
REGION="us-central1"
DATASET="incontact"
JOB_NAME="incontact-call-processor"
BATCH_SIZE=100

CALL_FILE="${1:-}"
if [ -z "$CALL_FILE" ]; then
  echo "Usage: bash batch_loader.sh <call_ids_file.txt>"
  echo ""
  echo "The file should have one call ID per line."
  exit 1
fi

if [ ! -f "$CALL_FILE" ]; then
  echo "Error: File '$CALL_FILE' not found."
  exit 1
fi

TOTAL_CALLS=$(grep -c '[0-9]' "$CALL_FILE" || echo 0)
echo "=== InContact Batch Loader ==="
echo "File:       $CALL_FILE"
echo "Total IDs:  $TOTAL_CALLS"
echo "Batch size: $BATCH_SIZE"
echo ""

BATCH_NUM=0
LOADED=0
CALL_BUFFER=""
COUNT=0

while IFS= read -r line || [ -n "$line" ]; do
  CALL_ID=$(echo "$line" | tr -d '[:space:]')
  [ -z "$CALL_ID" ] && continue

  if [ -z "$CALL_BUFFER" ]; then
    CALL_BUFFER="(GENERATE_UUID(), '${CALL_ID}', 'pending', CURRENT_TIMESTAMP(), 'batch-$(printf '%03d' $((BATCH_NUM + 1)))')"
  else
    CALL_BUFFER="${CALL_BUFFER}, (GENERATE_UUID(), '${CALL_ID}', 'pending', CURRENT_TIMESTAMP(), 'batch-$(printf '%03d' $((BATCH_NUM + 1)))')"
  fi
  COUNT=$((COUNT + 1))

  if [ "$COUNT" -ge "$BATCH_SIZE" ]; then
    BATCH_NUM=$((BATCH_NUM + 1))
    LOADED=$((LOADED + COUNT))
    echo "--- Batch $BATCH_NUM: Loading $COUNT calls ($LOADED / $TOTAL_CALLS) ---"

    bq query --use_legacy_sql=false \
      "INSERT INTO \`${PROJECT}.${DATASET}.staging_call_queue\` (id, call_id, status, created_at, batch_id) VALUES ${CALL_BUFFER}"

    echo "    Inserted. Running job..."
    gcloud run jobs execute "$JOB_NAME" --project="$PROJECT" --region="$REGION" --wait

    echo "    Job finished. Checking results..."
    bq query --use_legacy_sql=false --format=csv \
      "SELECT status, COUNT(*) as cnt FROM \`${PROJECT}.${DATASET}.staging_call_queue\` WHERE batch_id = 'batch-$(printf '%03d' $BATCH_NUM)' GROUP BY status"

    echo ""
    CALL_BUFFER=""
    COUNT=0
  fi
done < "$CALL_FILE"

if [ "$COUNT" -gt 0 ]; then
  BATCH_NUM=$((BATCH_NUM + 1))
  LOADED=$((LOADED + COUNT))
  echo "--- Batch $BATCH_NUM: Loading $COUNT calls ($LOADED / $TOTAL_CALLS) ---"

  bq query --use_legacy_sql=false \
    "INSERT INTO \`${PROJECT}.${DATASET}.staging_call_queue\` (id, call_id, status, created_at, batch_id) VALUES ${CALL_BUFFER}"

  echo "    Inserted. Running job..."
  gcloud run jobs execute "$JOB_NAME" --project="$PROJECT" --region="$REGION" --wait

  echo "    Job finished. Checking results..."
  bq query --use_legacy_sql=false --format=csv \
    "SELECT status, COUNT(*) as cnt FROM \`${PROJECT}.${DATASET}.staging_call_queue\` WHERE batch_id = 'batch-$(printf '%03d' $BATCH_NUM)' GROUP BY status"

  echo ""
fi

echo "=== Complete ==="
echo "Total batches: $BATCH_NUM"
echo "Total loaded:  $LOADED"
echo ""
echo "Overall summary:"
bq query --use_legacy_sql=false \
  "SELECT status, COUNT(*) as cnt FROM \`${PROJECT}.${DATASET}.staging_call_queue\` GROUP BY status ORDER BY status"
