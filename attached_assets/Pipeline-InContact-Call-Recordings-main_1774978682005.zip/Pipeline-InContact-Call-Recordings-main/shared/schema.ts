import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const phases = pgTable("phases", {
  id: varchar("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  status: text("status").notNull().default("pending"),
  icon: text("icon").notNull().default("Cloud"),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const tasks = pgTable("tasks", {
  id: varchar("id").primaryKey(),
  phaseId: varchar("phase_id").notNull(),
  name: text("name").notNull(),
  done: boolean("done").notNull().default(false),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const secrets = pgTable("secrets", {
  id: varchar("id").primaryKey(),
  name: text("name").notNull(),
  version: text("version").notNull().default("1"),
  status: text("status").notNull().default("active"),
  lastRotated: text("last_rotated").notNull(),
});

export const batches = pgTable("batches", {
  id: varchar("id").primaryKey(),
  status: text("status").notNull().default("pending"),
  totalRecords: integer("total_records").notNull().default(0),
  processedRecords: integer("processed_records").notNull().default(0),
  sizeBytes: text("size_bytes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const schemaFields = pgTable("schema_fields", {
  id: varchar("id").primaryKey(),
  tableName: text("table_name").notNull(),
  field: text("field").notNull(),
  fieldType: text("field_type").notNull(),
  mode: text("mode").notNull().default("NULLABLE"),
  description: text("description").notNull(),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const callQueue = pgTable("call_queue", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  callId: text("call_id").notNull(),
  status: text("status").notNull().default("pending"),
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  processedAt: timestamp("processed_at"),
  batchId: text("batch_id"),
});

export const callRecordings = pgTable("call_recordings", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  contactId: text("contact_id").notNull(),
  acdContactId: text("acd_contact_id").notNull(),
  agentId: text("agent_id"),
  agentName: text("agent_name"),
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  durationSeconds: integer("duration_seconds"),
  mediaType: text("media_type"),
  direction: text("direction"),
  fileName: text("file_name"),
  gcsUri: text("gcs_uri"),
  fileSizeBytes: integer("file_size_bytes"),
  sentiment: text("sentiment"),
  categories: text("categories"),
  callTags: text("call_tags"),
  rawJson: text("raw_json"),
  ingestionTimestamp: timestamp("ingestion_timestamp").notNull().defaultNow(),
});

export const insertPhaseSchema = createInsertSchema(phases);
export const insertTaskSchema = createInsertSchema(tasks);
export const insertSecretSchema = createInsertSchema(secrets);
export const insertBatchSchema = createInsertSchema(batches);
export const insertSchemaFieldSchema = createInsertSchema(schemaFields);
export const insertCallQueueSchema = createInsertSchema(callQueue).omit({ id: true, createdAt: true, processedAt: true });
export const insertCallRecordingSchema = createInsertSchema(callRecordings).omit({ id: true, ingestionTimestamp: true });

export type Phase = typeof phases.$inferSelect;
export type InsertPhase = z.infer<typeof insertPhaseSchema>;
export type Task = typeof tasks.$inferSelect;
export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Secret = typeof secrets.$inferSelect;
export type InsertSecret = z.infer<typeof insertSecretSchema>;
export type Batch = typeof batches.$inferSelect;
export type InsertBatch = z.infer<typeof insertBatchSchema>;
export type SchemaField = typeof schemaFields.$inferSelect;
export type InsertSchemaField = z.infer<typeof insertSchemaFieldSchema>;
export type CallQueueItem = typeof callQueue.$inferSelect;
export type InsertCallQueueItem = z.infer<typeof insertCallQueueSchema>;
export type CallRecording = typeof callRecordings.$inferSelect;
export type InsertCallRecording = z.infer<typeof insertCallRecordingSchema>;
