CREATE OR REPLACE VIEW `guidewaycare-476802.incontact.v_pending_downloads` AS
SELECT
  id,
  call_id,
  status,
  created_at,
  batch_id
FROM
  `guidewaycare-476802.incontact.staging_call_queue`
WHERE
  status = 'pending'
ORDER BY
  created_at ASC,
  id ASC
LIMIT 1000;
