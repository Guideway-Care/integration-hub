#!/bin/bash
set -euo pipefail

PROJECT="guidewaycare-476802"
DATASET="incontact"

echo "=== Deploying BigQuery DDL to ${PROJECT}.${DATASET} ==="
echo ""

for sql_file in $(ls bq/[0-9]*.sql | sort); do
  echo "▶ Running: ${sql_file}"
  bq query \
    --project_id="${PROJECT}" \
    --use_legacy_sql=false \
    --format=prettyjson \
    < "${sql_file}"
  echo "  ✓ Done"
  echo ""
done

echo "=== All DDL deployed successfully ==="
echo ""
echo "Tables created:"
bq ls --project_id="${PROJECT}" "${DATASET}"
