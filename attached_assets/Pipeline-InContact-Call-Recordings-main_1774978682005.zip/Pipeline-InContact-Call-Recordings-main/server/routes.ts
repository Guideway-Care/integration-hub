import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { SecretManagerServiceClient } from "@google-cloud/secret-manager";
import { Storage as GCSStorage } from "@google-cloud/storage";
import { BigQuery } from "@google-cloud/bigquery";
import { z } from "zod";
import { Readable } from "stream";

const ALLOWED_ENDPOINTS = [
  "/media-playback/v1/contacts",
  "/incontactapi/services/v30.0/contacts/completed",
  "/incontactapi/services/v30.0/contacts/active",
  "/incontactapi/services/v30.0/agents",
  "/incontactapi/services/v30.0/skills/summary",
];

const fetchBodySchema = z.object({
  endpoint: z.string().refine((val) => ALLOWED_ENDPOINTS.includes(val), {
    message: "Endpoint not in allowlist",
  }),
  params: z.record(z.string()).optional(),
});

const BQ_PROJECT = "guidewaycare-476802";
const BQ_DATASET = "incontact";
const BQ_STAGING = `${BQ_PROJECT}.${BQ_DATASET}.staging_call_queue`;
const BQ_RECORDINGS = `${BQ_PROJECT}.${BQ_DATASET}.call_recordings`;

function getGcpCredentials(): { credentials?: any } {
  const gcpKey = process.env.GCP_SERVICE_ACCOUNT_KEY;
  if (gcpKey) {
    return { credentials: JSON.parse(gcpKey) };
  }
  return {};
}

function getBigQueryClient() {
  return new BigQuery({ projectId: BQ_PROJECT, ...getGcpCredentials() });
}

function getGCSClient() {
  return new GCSStorage({ projectId: BQ_PROJECT, ...getGcpCredentials() });
}

async function getGcpSecretManagerClient() {
  const creds = getGcpCredentials();
  const client = new SecretManagerServiceClient(creds);
  return { client, projectId: BQ_PROJECT };
}

async function getSecretValue(client: SecretManagerServiceClient, projectId: string, secretName: string): Promise<string> {
  const name = `projects/${projectId}/secrets/${secretName}/versions/latest`;
  const [version] = await client.accessSecretVersion({ name });
  const value = version.payload?.data?.toString();
  if (!value) throw new Error(`Secret ${secretName} is empty`);
  return value;
}

async function getInContactBearerToken(): Promise<{ token: string; projectId: string; resourceServerBaseUri: string }> {
  const { client, projectId } = await getGcpSecretManagerClient();
  const accessKeyId = await getSecretValue(client, projectId, "inContact-Client-Id");
  const accessKeySecret = await getSecretValue(client, projectId, "inContact-Client-Secret");

  const tokenResponse = await fetch("https://na1.nice-incontact.com/authentication/v1/token/access-key", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      accessKeyId,
      accessKeySecret,
    }),
  });

  if (!tokenResponse.ok) {
    const errText = await tokenResponse.text();
    throw new Error(`Token request failed (${tokenResponse.status}): ${errText}`);
  }

  const tokenData = await tokenResponse.json() as any;
  const resourceServerBaseUri = tokenData.resource_server_base_uri || "https://na1.nice-incontact.com";
  return { token: tokenData.access_token, projectId, resourceServerBaseUri };
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  app.get("/api/phases", async (_req, res) => {
    const allPhases = await storage.getPhases();
    const allTasks = await storage.getAllTasks();
    const result = allPhases.map(phase => ({
      ...phase,
      tasks: allTasks.filter(t => t.phaseId === phase.id),
    }));
    res.json(result);
  });

  app.patch("/api/phases/:id/status", async (req, res) => {
    const { status } = req.body;
    const updated = await storage.updatePhaseStatus(req.params.id, status);
    if (!updated) return res.status(404).json({ message: "Phase not found" });
    res.json(updated);
  });

  app.patch("/api/tasks/:id", async (req, res) => {
    const { done } = req.body;
    const updated = await storage.updateTaskDone(req.params.id, done);
    if (!updated) return res.status(404).json({ message: "Task not found" });
    res.json(updated);
  });

  app.get("/api/secrets", async (_req, res) => {
    const allSecrets = await storage.getSecrets();
    res.json(allSecrets);
  });

  app.get("/api/batches", async (_req, res) => {
    const allBatches = await storage.getBatches();
    res.json(allBatches);
  });

  app.get("/api/schema/:tableName", async (req, res) => {
    const fields = await storage.getSchemaFields(req.params.tableName);
    res.json(fields);
  });

  app.get("/api/incontact/test", async (_req, res) => {
    try {
      const { client, projectId } = await getGcpSecretManagerClient();
      const clientId = await getSecretValue(client, projectId, "inContact-Client-Id");
      const clientSecret = await getSecretValue(client, projectId, "inContact-Client-Secret");
      res.json({
        status: "connected",
        secretRetrieved: true,
        project: projectId,
        secrets: ["inContact-Client-Id", "inContact-Client-Secret"],
        timestamp: new Date().toISOString(),
      });
    } catch (err: any) {
      console.error("[incontact/test]", err.message);
      const isConfig = err.message.includes("not configured");
      res.status(500).json({ error: isConfig ? "GCP service account not configured" : "Unable to connect to GCP Secret Manager" });
    }
  });

  app.get("/api/incontact/endpoints", (_req, res) => {
    res.json(ALLOWED_ENDPOINTS);
  });

  app.post("/api/incontact/auth-test", async (_req, res) => {
    try {
      const { token, resourceServerBaseUri } = await getInContactBearerToken();
      res.json({
        authenticated: true,
        resourceServerBaseUri,
        tokenLength: token.length,
        timestamp: new Date().toISOString(),
      });
    } catch (err: any) {
      console.error("[incontact/auth-test]", err.message);
      res.status(500).json({ error: "Authentication failed — check that your Client ID and Secret are valid access keys" });
    }
  });

  app.post("/api/incontact/fetch", async (req, res) => {
    try {
      const parsed = fetchBodySchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.issues[0].message });
      }

      const { token, resourceServerBaseUri } = await getInContactBearerToken();
      const { endpoint, params } = parsed.data;

      const url = new URL(`${resourceServerBaseUri}${endpoint}`);
      if (params) {
        Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v));
      }

      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 30000);

      const apiResponse = await fetch(url.toString(), {
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: "application/json",
        },
        signal: controller.signal,
      });
      clearTimeout(timeout);

      const contentType = apiResponse.headers.get("content-type") || "";
      let data: any;
      if (contentType.includes("application/json")) {
        data = await apiResponse.json();
      } else {
        data = await apiResponse.text();
      }

      res.json({
        statusCode: apiResponse.status,
        statusText: apiResponse.statusText,
        endpoint: url.pathname,
        timestamp: new Date().toISOString(),
        data,
      });
    } catch (err: any) {
      console.error("[incontact/fetch]", err.message);
      res.status(500).json({ error: "Failed to fetch from InContact API" });
    }
  });

  app.get("/api/call-queue", async (_req, res) => {
    const queue = await storage.getCallQueue();
    res.json(queue);
  });

  app.post("/api/call-queue", async (req, res) => {
    try {
      const schema = z.object({
        callIds: z.array(z.string().min(1)).min(1).max(500),
      });
      const parsed = schema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.issues[0].message });
      }
      const items = parsed.data.callIds.map((callId) => ({ callId, status: "pending" as const }));
      const created = await storage.addToCallQueue(items);
      res.json({ added: created.length, items: created });
    } catch (err: any) {
      console.error("[call-queue/add]", err.message);
      res.status(500).json({ error: "Failed to add call IDs to queue" });
    }
  });

  app.delete("/api/call-queue", async (_req, res) => {
    await storage.clearCallQueue();
    res.json({ message: "Queue cleared" });
  });

  app.get("/api/call-recordings", async (_req, res) => {
    const recordings = await storage.getCallRecordings();
    res.json(recordings);
  });

  let isProcessing = false;

  app.post("/api/call-queue/process", async (_req, res) => {
    if (isProcessing) {
      return res.status(409).json({ error: "Processing is already running" });
    }
    isProcessing = true;
    res.json({ message: "Processing started" });

    try {
      const gcsClient = getGCSClient();
      const bucket = gcsClient.bucket("incontact-audio");

      while (true) {
        const next = await storage.getNextPendingCall();
        if (!next) break;

        await storage.updateCallQueueStatus(next.id, "processing");

        try {
          const { token, resourceServerBaseUri } = await getInContactBearerToken();
          const url = new URL(`${resourceServerBaseUri}/media-playback/v1/contacts`);
          url.searchParams.set("acd-call-id", next.callId);

          const controller = new AbortController();
          const timeout = setTimeout(() => controller.abort(), 60000);
          const apiResponse = await fetch(url.toString(), {
            headers: { Authorization: `Bearer ${token}`, Accept: "application/json" },
            signal: controller.signal,
          });
          clearTimeout(timeout);

          if (!apiResponse.ok) {
            throw new Error(`API returned ${apiResponse.status}: ${await apiResponse.text()}`);
          }

          const data = await apiResponse.json() as any;
          const interaction = data.interactions?.[0];
          const interactionData = interaction?.data;
          const agent = interactionData?.participantDataList?.find((p: any) => p.participantType === "AGENT");
          const segment = interactionData?.segmentsDataList?.[0];
          const sentiments = interactionData?.sentiments || [];
          const categories = interactionData?.categoryMatchesList || [];
          const callTags = interaction?.callTaggingList || [];

          let durationSeconds: number | null = null;
          if (interactionData?.startTime && interactionData?.endTime) {
            durationSeconds = Math.floor(
              (new Date(interactionData.endTime).getTime() - new Date(interactionData.startTime).getTime()) / 1000
            );
          }

          let gcsUri: string | null = null;
          let fileSizeBytes: number | null = null;
          const fileUrl = interactionData?.fileToPlayUrl;

          if (fileUrl) {
            const mediaResponse = await fetch(fileUrl);
            if (!mediaResponse.ok || !mediaResponse.body) {
              throw new Error(`Failed to download recording: HTTP ${mediaResponse.status}`);
            }
            const fileName = `${next.callId}.mp4`;
            const file = bucket.file(fileName);
            const contentLength = mediaResponse.headers.get("content-length");
            fileSizeBytes = contentLength ? parseInt(contentLength) : null;

            const nodeStream = Readable.fromWeb(mediaResponse.body as any);
            await new Promise<void>((resolve, reject) => {
              nodeStream
                .pipe(file.createWriteStream({ contentType: "video/mp4", resumable: false }))
                .on("finish", resolve)
                .on("error", reject);
            });

            gcsUri = `gs://incontact-audio/${fileName}`;
            console.log(`[process] Uploaded ${fileName} to GCS`);
          }

          await storage.createCallRecording({
            contactId: data.contactId || "",
            acdContactId: data.acdcontactId || next.callId,
            agentId: agent?.participantId || null,
            agentName: agent?.agentName || null,
            startDate: interactionData?.startTime ? new Date(interactionData.startTime) : null,
            endDate: interactionData?.endTime ? new Date(interactionData.endTime) : null,
            durationSeconds,
            mediaType: interaction?.mediaType || null,
            direction: segment?.directionType || null,
            fileName: gcsUri ? `${next.callId}.mp4` : null,
            gcsUri,
            fileSizeBytes,
            sentiment: sentiments.length > 0 ? JSON.stringify(sentiments) : null,
            categories: categories.length > 0 ? JSON.stringify(categories) : null,
            callTags: callTags.length > 0 ? JSON.stringify(callTags.map((t: any) => t.value)) : null,
            rawJson: JSON.stringify(data),
          });

          await storage.updateCallQueueStatus(next.id, "downloaded");
          console.log(`[process] Downloaded call ${next.callId}`);
        } catch (err: any) {
          console.error(`[process] Failed call ${next.callId}:`, err.message);
          await storage.updateCallQueueStatus(next.id, "failed", err.message);
        }
      }
    } catch (err: any) {
      console.error("[process] Fatal error:", err.message);
    } finally {
      isProcessing = false;
    }
  });

  app.get("/api/call-queue/status", (_req, res) => {
    res.json({ isProcessing });
  });

  app.post("/api/seed", async (_req, res) => {
    const existingPhases = await storage.getPhases();
    if (existingPhases.length > 0) {
      return res.json({ message: "Already seeded" });
    }

    const phaseData = [
      { id: "phase-1", title: "Environment Setup & Security", description: "Configure GCP project, datasets, buckets, and Secret Manager.", status: "done", icon: "Cloud", sortOrder: 0 },
      { id: "phase-2", title: "Data Architecture", description: "Design and deploy BigQuery schemas for metadata.", status: "done", icon: "Database", sortOrder: 1 },
      { id: "phase-3", title: "API Integration & Cloud Run", description: "Develop scripts to retrieve data from getACDContactRecordingData API.", status: "done", icon: "Server", sortOrder: 2 },
      { id: "phase-4", title: "Initial Historical Load", description: "Retrieve initial set of calls based on a predefined BQ table list.", status: "in-progress", icon: "FileAudio", sortOrder: 3 },
      { id: "phase-5", title: "Daily Delta Process", description: "Setup Cloud Scheduler to run daily retrievals.", status: "pending", icon: "Activity", sortOrder: 4 },
    ];

    for (const p of phaseData) {
      await storage.createPhase(p);
    }

    const taskData = [
      { id: "t1", phaseId: "phase-1", name: "Create dataset 'incontact' in guidewaycare-476802", done: true, sortOrder: 0 },
      { id: "t2", phaseId: "phase-1", name: "Create bucket 'incontact-audio' for call recordings", done: true, sortOrder: 1 },
      { id: "t3", phaseId: "phase-1", name: "Configure GCP Key Management for API keys (inContact-Access-Key)", done: true, sortOrder: 2 },
      { id: "t4", phaseId: "phase-1", name: "Setup GitHub repository and CI/CD pipelines (Pipeline-InContact-Call-Recordings)", done: true, sortOrder: 3 },
      { id: "t5", phaseId: "phase-2", name: "Propose metadata table schema", done: true, sortOrder: 0 },
      { id: "t6", phaseId: "phase-2", name: "Create staging tables in BQ", done: true, sortOrder: 1 },
      { id: "t7", phaseId: "phase-2", name: "Create final destination tables in BQ", done: true, sortOrder: 2 },
      { id: "t8", phaseId: "phase-3", name: "Develop Node.js Cloud Run job for API retrieval", done: true, sortOrder: 0 },
      { id: "t9", phaseId: "phase-3", name: "Implement Secret Manager retrieval in scripts", done: true, sortOrder: 1 },
      { id: "t10", phaseId: "phase-3", name: "Deploy Cloud Run job with Cloud Build CI/CD", done: true, sortOrder: 2 },
      { id: "t11", phaseId: "phase-4", name: "Read target call list from BQ", done: false, sortOrder: 0 },
      { id: "t12", phaseId: "phase-4", name: "Execute batch API requests for metadata", done: false, sortOrder: 1 },
      { id: "t13", phaseId: "phase-4", name: "Download and store audio files to GCS bucket", done: false, sortOrder: 2 },
      { id: "t14", phaseId: "phase-5", name: "Configure logic to identify 'new' calls from previous day", done: false, sortOrder: 0 },
      { id: "t15", phaseId: "phase-5", name: "Setup Cloud Scheduler job to trigger Cloud Run", done: false, sortOrder: 1 },
      { id: "t16", phaseId: "phase-5", name: "Implement load balancing and staging controls", done: false, sortOrder: 2 },
    ];

    for (const t of taskData) {
      await storage.createTask(t);
    }

    await storage.createSecret({
      id: "sec-1",
      name: "inContact-Client-Id",
      version: "1",
      status: "active",
      lastRotated: "2026-03-11",
    });
    await storage.createSecret({
      id: "sec-2",
      name: "inContact-Client-Secret",
      version: "1",
      status: "active",
      lastRotated: "2026-03-11",
    });

    const stagingFields = [
      { id: "sf-1", tableName: "stg_call_recordings_raw", field: "raw_json", fieldType: "STRING", mode: "NULLABLE", description: "Raw JSON response from the API for audit and replayability.", sortOrder: 0 },
      { id: "sf-2", tableName: "stg_call_recordings_raw", field: "batch_id", fieldType: "STRING", mode: "REQUIRED", description: "Tracking ID for the retrieval batch execution.", sortOrder: 1 },
      { id: "sf-3", tableName: "stg_call_recordings_raw", field: "load_timestamp", fieldType: "TIMESTAMP", mode: "REQUIRED", description: "When this record hit the staging table.", sortOrder: 2 },
    ];

    const destFields = [
      { id: "df-1", tableName: "call_recordings", field: "contact_id", fieldType: "INT64", mode: "REQUIRED", description: "Unique identifier for the contact/call.", sortOrder: 0 },
      { id: "df-2", tableName: "call_recordings", field: "master_contact_id", fieldType: "INT64", mode: "NULLABLE", description: "Master ID tying related contacts together.", sortOrder: 1 },
      { id: "df-3", tableName: "call_recordings", field: "agent_id", fieldType: "INT64", mode: "NULLABLE", description: "System ID of the agent.", sortOrder: 2 },
      { id: "df-4", tableName: "call_recordings", field: "agent_name", fieldType: "STRING", mode: "NULLABLE", description: "Name of the agent handling the contact.", sortOrder: 3 },
      { id: "df-5", tableName: "call_recordings", field: "start_date", fieldType: "TIMESTAMP", mode: "REQUIRED", description: "Start time of the recording in UTC.", sortOrder: 4 },
      { id: "df-6", tableName: "call_recordings", field: "duration_seconds", fieldType: "INT64", mode: "NULLABLE", description: "Duration of the recording in seconds.", sortOrder: 5 },
      { id: "df-7", tableName: "call_recordings", field: "media_type", fieldType: "STRING", mode: "NULLABLE", description: "Format of the audio (e.g., wav, mp3).", sortOrder: 6 },
      { id: "df-8", tableName: "call_recordings", field: "file_name", fieldType: "STRING", mode: "REQUIRED", description: "Original filename from InContact.", sortOrder: 7 },
      { id: "df-9", tableName: "call_recordings", field: "gcs_uri", fieldType: "STRING", mode: "REQUIRED", description: "gs://incontact-audio path where the file is stored.", sortOrder: 8 },
      { id: "df-10", tableName: "call_recordings", field: "file_size_bytes", fieldType: "INT64", mode: "NULLABLE", description: "Size of the stored file in bytes.", sortOrder: 9 },
      { id: "df-11", tableName: "call_recordings", field: "ingestion_timestamp", fieldType: "TIMESTAMP", mode: "REQUIRED", description: "When the record was fully processed.", sortOrder: 10 },
    ];

    for (const f of [...stagingFields, ...destFields]) {
      await storage.createSchemaField(f);
    }

    await storage.createBatch({ id: "B-8490", status: "completed", totalRecords: 500, processedRecords: 500, sizeBytes: "1.4 GB" });
    await storage.createBatch({ id: "B-8491", status: "completed", totalRecords: 500, processedRecords: 500, sizeBytes: "1.2 GB" });
    await storage.createBatch({ id: "B-8492", status: "processing", totalRecords: 500, processedRecords: 250, sizeBytes: null });

    res.json({ message: "Seed data created" });
  });

  app.get("/api/bq/staging-summary", async (_req, res) => {
    try {
      const bq = getBigQueryClient();
      const [rows] = await bq.query({
        query: `SELECT status, COUNT(*) as count FROM \`${BQ_STAGING}\` GROUP BY status ORDER BY status`,
      });
      const summary: Record<string, number> = { pending: 0, processing: 0, downloaded: 0, failed: 0 };
      rows.forEach((r: any) => { summary[r.status] = Number(r.count); });
      const total = Object.values(summary).reduce((a, b) => a + b, 0);
      res.json({ ...summary, total });
    } catch (err: any) {
      console.error("[bq/staging-summary]", err.message);
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/bq/staging-queue", async (_req, res) => {
    try {
      const bq = getBigQueryClient();
      const [rows] = await bq.query({
        query: `SELECT id, call_id, status, error_message, batch_id, 
                FORMAT_TIMESTAMP('%Y-%m-%dT%H:%M:%SZ', created_at) as created_at, 
                FORMAT_TIMESTAMP('%Y-%m-%dT%H:%M:%SZ', processed_at) as processed_at
                FROM \`${BQ_STAGING}\` ORDER BY created_at DESC LIMIT 200`,
      });
      res.json(rows);
    } catch (err: any) {
      console.error("[bq/staging-queue]", err.message);
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/bq/recordings", async (_req, res) => {
    try {
      const bq = getBigQueryClient();
      const [rows] = await bq.query({
        query: `SELECT id, contact_id, acd_contact_id, agent_id, agent_name, 
                FORMAT_TIMESTAMP('%Y-%m-%dT%H:%M:%SZ', start_date) as start_date,
                FORMAT_TIMESTAMP('%Y-%m-%dT%H:%M:%SZ', end_date) as end_date,
                duration_seconds, media_type, direction, file_name, gcs_uri, file_size_bytes,
                call_tags, FORMAT_TIMESTAMP('%Y-%m-%dT%H:%M:%SZ', ingestion_timestamp) as ingestion_timestamp
                FROM \`${BQ_RECORDINGS}\` ORDER BY ingestion_timestamp DESC LIMIT 200`,
      });
      res.json(rows);
    } catch (err: any) {
      console.error("[bq/recordings]", err.message);
      res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/bq/staging-add", async (req, res) => {
    try {
      const schema = z.object({
        callIds: z.array(z.string().min(1)).min(1).max(500),
        batchId: z.string().optional(),
      });
      const parsed = schema.safeParse(req.body);
      if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });

      const bq = getBigQueryClient();
      const batchId = parsed.data.batchId || `batch-${Date.now()}`;
      const callIdRegex = /^\d{6,20}$/;
      const validIds = parsed.data.callIds.filter((id) => callIdRegex.test(id));
      if (validIds.length === 0) return res.status(400).json({ error: "No valid call IDs (must be 6-20 digits)" });

      for (const callId of validIds) {
        await bq.query({
          query: `INSERT INTO \`${BQ_STAGING}\` (id, call_id, status, created_at, batch_id) VALUES (GENERATE_UUID(), @callId, 'pending', CURRENT_TIMESTAMP(), @batchId)`,
          params: { callId, batchId },
        });
      }

      res.json({ added: validIds.length, batchId });
    } catch (err: any) {
      console.error("[bq/staging-add]", err.message);
      res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/bq/staging-clear", async (_req, res) => {
    try {
      const bq = getBigQueryClient();
      await bq.query({ query: `DELETE FROM \`${BQ_STAGING}\` WHERE true` });
      await bq.query({ query: `DELETE FROM \`${BQ_RECORDINGS}\` WHERE true` });
      res.json({ message: "Tables cleared" });
    } catch (err: any) {
      console.error("[bq/staging-clear]", err.message);
      res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/bq/staging-reset-failed", async (_req, res) => {
    try {
      const bq = getBigQueryClient();
      await bq.query({
        query: `UPDATE \`${BQ_STAGING}\` SET status = 'pending', error_message = NULL, processed_at = NULL WHERE status = 'failed'`,
      });
      res.json({ message: "Failed rows reset to pending" });
    } catch (err: any) {
      console.error("[bq/staging-reset-failed]", err.message);
      res.status(500).json({ error: err.message });
    }
  });

  async function triggerCloudRunJob(jobName: string) {
    const { google } = await import("googleapis");
    const creds = getGcpCredentials();
    const auth = new google.auth.GoogleAuth({
      ...(creds.credentials ? { credentials: creds.credentials } : {}),
      scopes: ["https://www.googleapis.com/auth/cloud-platform"],
    });
    const client = await auth.getClient();
    const accessToken = await client.getAccessToken();

    const runRes = await fetch(
      `https://run.googleapis.com/v2/projects/${BQ_PROJECT}/locations/us-central1/jobs/${jobName}:run`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${accessToken.token}`,
          "Content-Type": "application/json",
        },
      }
    );

    if (!runRes.ok) {
      const errText = await runRes.text();
      throw new Error(`Cloud Run API returned ${runRes.status}: ${errText}`);
    }

    const data = await runRes.json();
    return { message: "Job started", executionName: data.metadata?.name || data.name };
  }

  app.post("/api/bq/run-job", async (_req, res) => {
    try {
      const result = await triggerCloudRunJob("incontact-call-processor");
      res.json(result);
    } catch (err: any) {
      console.error("[bq/run-job]", err.message);
      res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/bq/run-loader", async (_req, res) => {
    try {
      const result = await triggerCloudRunJob("incontact-call-loader");
      res.json(result);
    } catch (err: any) {
      console.error("[bq/run-loader]", err.message);
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/bq/call-list-status", async (_req, res) => {
    try {
      const gcsClient = getGCSClient();
      const file = gcsClient.bucket("incontact-audio").file("call_list/call_list.txt");
      const [exists] = await file.exists();
      if (!exists) {
        return res.json({ exists: false, lineCount: 0 });
      }
      const [contents] = await file.download();
      const lines = contents.toString("utf-8").split(/\r?\n/).map(l => l.trim()).filter(l => /^\d{6,20}$/.test(l));
      res.json({ exists: true, lineCount: lines.length });
    } catch (err: any) {
      console.error("[bq/call-list-status]", err.message);
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/download/cloud-run-index", (_req, res) => {
    const filePath = new URL("../cloud-run/index.js", import.meta.url).pathname;
    res.download(filePath, "index.js");
  });

  app.get("/api/download/batch-loader", (_req, res) => {
    const filePath = new URL("../cloud-run/batch_loader.sh", import.meta.url).pathname;
    res.download(filePath, "batch_loader.sh");
  });

  app.get("/api/download/cloud-run-loader", (_req, res) => {
    const filePath = new URL("../cloud-run/loader.js", import.meta.url).pathname;
    res.download(filePath, "loader.js");
  });

  return httpServer;
}
