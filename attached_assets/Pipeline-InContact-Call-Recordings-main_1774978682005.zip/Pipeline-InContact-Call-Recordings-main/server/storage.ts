import {
  type Phase, type InsertPhase,
  type Task, type InsertTask,
  type Secret, type InsertSecret,
  type Batch, type InsertBatch,
  type SchemaField, type InsertSchemaField,
  type CallQueueItem, type InsertCallQueueItem,
  type CallRecording, type InsertCallRecording,
  phases, tasks, secrets, batches, schemaFields, callQueue, callRecordings,
} from "@shared/schema";
import { db } from "./db";
import { eq, asc, desc } from "drizzle-orm";

function requireDb() {
  if (!db) throw new Error("Database not configured (DATABASE_URL not set)");
  return db;
}

export interface IStorage {
  getPhases(): Promise<Phase[]>;
  getPhase(id: string): Promise<Phase | undefined>;
  createPhase(phase: InsertPhase): Promise<Phase>;
  updatePhaseStatus(id: string, status: string): Promise<Phase | undefined>;

  getTasks(phaseId: string): Promise<Task[]>;
  getAllTasks(): Promise<Task[]>;
  createTask(task: InsertTask): Promise<Task>;
  updateTaskDone(id: string, done: boolean): Promise<Task | undefined>;

  getSecrets(): Promise<Secret[]>;
  createSecret(secret: InsertSecret): Promise<Secret>;
  updateSecretVersion(id: string, version: string, lastRotated: string): Promise<Secret | undefined>;

  getBatches(): Promise<Batch[]>;
  createBatch(batch: InsertBatch): Promise<Batch>;
  updateBatch(id: string, updates: Partial<InsertBatch>): Promise<Batch | undefined>;

  getSchemaFields(tableName: string): Promise<SchemaField[]>;
  createSchemaField(field: InsertSchemaField): Promise<SchemaField>;

  getCallQueue(): Promise<CallQueueItem[]>;
  addToCallQueue(items: InsertCallQueueItem[]): Promise<CallQueueItem[]>;
  updateCallQueueStatus(id: number, status: string, errorMessage?: string): Promise<CallQueueItem | undefined>;
  getNextPendingCall(): Promise<CallQueueItem | undefined>;
  clearCallQueue(): Promise<void>;

  getCallRecordings(): Promise<CallRecording[]>;
  createCallRecording(recording: InsertCallRecording): Promise<CallRecording>;
}

export class DatabaseStorage implements IStorage {
  async getPhases(): Promise<Phase[]> {
    return requireDb().select().from(phases).orderBy(asc(phases.sortOrder));
  }

  async getPhase(id: string): Promise<Phase | undefined> {
    const [phase] = await requireDb().select().from(phases).where(eq(phases.id, id));
    return phase;
  }

  async createPhase(phase: InsertPhase): Promise<Phase> {
    const [created] = await requireDb().insert(phases).values(phase).returning();
    return created;
  }

  async updatePhaseStatus(id: string, status: string): Promise<Phase | undefined> {
    const [updated] = await requireDb().update(phases).set({ status }).where(eq(phases.id, id)).returning();
    return updated;
  }

  async getTasks(phaseId: string): Promise<Task[]> {
    return requireDb().select().from(tasks).where(eq(tasks.phaseId, phaseId)).orderBy(asc(tasks.sortOrder));
  }

  async getAllTasks(): Promise<Task[]> {
    return requireDb().select().from(tasks).orderBy(asc(tasks.sortOrder));
  }

  async createTask(task: InsertTask): Promise<Task> {
    const [created] = await requireDb().insert(tasks).values(task).returning();
    return created;
  }

  async updateTaskDone(id: string, done: boolean): Promise<Task | undefined> {
    const [updated] = await requireDb().update(tasks).set({ done }).where(eq(tasks.id, id)).returning();
    return updated;
  }

  async getSecrets(): Promise<Secret[]> {
    return requireDb().select().from(secrets);
  }

  async createSecret(secret: InsertSecret): Promise<Secret> {
    const [created] = await requireDb().insert(secrets).values(secret).returning();
    return created;
  }

  async updateSecretVersion(id: string, version: string, lastRotated: string): Promise<Secret | undefined> {
    const [updated] = await requireDb().update(secrets).set({ version, lastRotated, status: "active" }).where(eq(secrets.id, id)).returning();
    return updated;
  }

  async getBatches(): Promise<Batch[]> {
    return requireDb().select().from(batches).orderBy(asc(batches.createdAt));
  }

  async createBatch(batch: InsertBatch): Promise<Batch> {
    const [created] = await requireDb().insert(batches).values(batch).returning();
    return created;
  }

  async updateBatch(id: string, updates: Partial<InsertBatch>): Promise<Batch | undefined> {
    const [updated] = await requireDb().update(batches).set(updates).where(eq(batches.id, id)).returning();
    return updated;
  }

  async getSchemaFields(tableName: string): Promise<SchemaField[]> {
    return requireDb().select().from(schemaFields).where(eq(schemaFields.tableName, tableName)).orderBy(asc(schemaFields.sortOrder));
  }

  async createSchemaField(field: InsertSchemaField): Promise<SchemaField> {
    const [created] = await requireDb().insert(schemaFields).values(field).returning();
    return created;
  }

  async getCallQueue(): Promise<CallQueueItem[]> {
    return requireDb().select().from(callQueue).orderBy(desc(callQueue.createdAt));
  }

  async addToCallQueue(items: InsertCallQueueItem[]): Promise<CallQueueItem[]> {
    return requireDb().insert(callQueue).values(items).returning();
  }

  async updateCallQueueStatus(id: number, status: string, errorMessage?: string): Promise<CallQueueItem | undefined> {
    const updates: any = { status };
    if (status === "downloaded" || status === "completed" || status === "failed") {
      updates.processedAt = new Date();
    }
    if (errorMessage !== undefined) {
      updates.errorMessage = errorMessage;
    }
    const [updated] = await requireDb().update(callQueue).set(updates).where(eq(callQueue.id, id)).returning();
    return updated;
  }

  async getNextPendingCall(): Promise<CallQueueItem | undefined> {
    const [next] = await requireDb().select().from(callQueue).where(eq(callQueue.status, "pending")).orderBy(asc(callQueue.createdAt)).limit(1);
    return next;
  }

  async clearCallQueue(): Promise<void> {
    await requireDb().delete(callQueue);
  }

  async getCallRecordings(): Promise<CallRecording[]> {
    return requireDb().select().from(callRecordings).orderBy(desc(callRecordings.ingestionTimestamp));
  }

  async createCallRecording(recording: InsertCallRecording): Promise<CallRecording> {
    const [created] = await requireDb().insert(callRecordings).values(recording).returning();
    return created;
  }
}

export const storage = new DatabaseStorage();
